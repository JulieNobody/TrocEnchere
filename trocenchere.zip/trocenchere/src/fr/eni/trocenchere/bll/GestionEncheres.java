package fr.eni.trocenchere.bll;

import fr.eni.trocenchere.bo.Encheres;
import fr.eni.trocenchere.dal.EncheresDAOJdbcImpl;
import fr.eni.trocenchere.dal.DALException;
import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import fr.eni.trocenchere.bo.Utilisateurs;
import fr.eni.trocenchere.dal.ConnectionProvider;

public class GestionEncheres {

	public static Encheres creationEnchere(Encheres enchere) throws SQLException, DALException
	{
		List<Encheres> liste =  new ArrayList<Encheres>();
		Encheres enchPlusHaute = new Encheres();
		enchPlusHaute.setMontantEnchere(0);
		EncheresDAOJdbcImpl manip = new EncheresDAOJdbcImpl();		
		liste=manip.selectByNoArticle(enchere.getNoArticle());
	//On verifie qu'il y a deja une enchere en place
	if(liste.size()>0) {	
		//Verification que l'enchere de l'utilisateur est plus haute que les autres
		for (Encheres ench : liste) {	
			//On cherche si l'utilisateur a mis une precedente enchere
				if(ench.getNoAcheteur()==enchere.getNoAcheteur()) {
					suppressionEnchere(enchere.getNoAcheteur(), enchere.getNoArticle());
				}
			//Ici on cherche l'enchere actuelle la plus haute pour la retournée et pouvoir redonner son argent a l'ancien user en pole pos
			if(enchPlusHaute.getMontantEnchere() < ench.getMontantEnchere()) {
				enchPlusHaute=ench;
			}
		}
	}
			
			manip.insert(enchere);

		//On recupere la derniere enchere la plus haute
		return enchPlusHaute;
	}
	
	public static boolean suppressionEnchere(int noUtilisateur, int noArticle) {
		EncheresDAOJdbcImpl manip = new EncheresDAOJdbcImpl();	
		try {
		manip.delete(noUtilisateur,noArticle);
		}catch(DALException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
}
