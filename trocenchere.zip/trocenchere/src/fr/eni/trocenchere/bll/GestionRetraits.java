package fr.eni.trocenchere.bll;

import java.sql.SQLException;

import fr.eni.trocenchere.bll.verifications.VerifRetrait;
import fr.eni.trocenchere.bo.Articles;
import fr.eni.trocenchere.bo.Retraits;
import fr.eni.trocenchere.dal.ArticlesDAO;
import fr.eni.trocenchere.dal.DALException;
import fr.eni.trocenchere.dal.DAOFactory;
import fr.eni.trocenchere.dal.RetraitsDAO;

public class GestionRetraits {

	public static boolean inscriptionRetrait(Retraits retraits) throws SQLException, BllException
	{

		RetraitsDAO manip = DAOFactory.getRetraitsDAO();
		boolean bool= false;
		try {
		VerifRetrait.champs(retraits);
		manip.insert(retraits);
		bool = true;
		}catch(DALException e) {
			e.printStackTrace();
			throw new BllException("Champ(s) invalide(s) lors de l'inscription");
		}
		return bool;
		
	}
	
	public static Retraits creationRetrait(int noArticle) throws SQLException
	{
		RetraitsDAO manip = DAOFactory.getRetraitsDAO();
		Retraits retraitRecherche;
		retraitRecherche = null;
		try {
			retraitRecherche = manip.selectByNoArticle(noArticle);
		} catch (DALException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retraitRecherche;
	}
	
	public static boolean modificationRetrait(Retraits retraits) throws SQLException, BllException
	{

		RetraitsDAO manip = DAOFactory.getRetraitsDAO();
		boolean bool= false;
		try {
		VerifRetrait.champs(retraits);
		manip.update(retraits);
		bool = true;
		}catch(DALException e) {
			e.printStackTrace();
			throw new BllException("Champ(s) invalide(s) lors de l'inscription");
		}
		return bool;
		
	}

	
}
