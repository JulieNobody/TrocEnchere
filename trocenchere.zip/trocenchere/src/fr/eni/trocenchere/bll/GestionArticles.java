package fr.eni.trocenchere.bll;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fr.eni.trocenchere.bo.Articles;
import fr.eni.trocenchere.bo.Utilisateurs;
import fr.eni.trocenchere.dal.ArticlesDAO;
import fr.eni.trocenchere.dal.DALException;
import fr.eni.trocenchere.dal.DAOFactory;
import fr.eni.trocenchere.dal.UtilisateurDAO;

public class GestionArticles {
//FIXME exceptions : gérer exceptions (Axel)
	
	/**insert un article dans la base de donnée
	 * @param article : article à inserer en BDD
	 * @return true si l'article a bien été inseré
	 * @throws SQLException
	 */
	public static boolean inscriptionArticle(Articles article) throws SQLException, BllException
	{
		//appel à la Factory
		ArticlesDAO manip = DAOFactory.getArticleDAO();
		
		//initialisation boolean pour le return
		boolean bool= false;
		
		try {
			//vérification des champs de l'article
			VerifArticle.champs(article);
			
			//appel à la méthode d'insertion de la DAL via la Factory
			manip.insert(article);
			bool = true;
		}catch(DALException e) {
			e.printStackTrace();
			throw new BllException("Champ(s) invalide(s) lors de l'inscription");
		}
		return bool;
	}
	
	/**récupere un article en BDD par son No
	 * @param noArticle : No de l'article à récuperer
	 * @return l'article recherché
	 * @throws SQLException
	 */
	public static Articles creationArticle(int noArticle) throws SQLException
	{
		//appel à la Factory
		ArticlesDAO manip = DAOFactory.getArticleDAO();
		
		Articles articleRecherche = null;
		try {
			//appel à la méthode de récupération d'un article by No de la DAL via la Factory
			articleRecherche = manip.selectByNo(noArticle);
		} catch (DALException e) {
			e.printStackTrace();
		}
		return articleRecherche;
	}
	
	/** modifie un article en BDD
	 * @param article : article à modifier en BDD
	 * @return true si l'article a bien été modifié
	 * @throws SQLException
	 */
	public static boolean modificationArticle(Articles article) throws SQLException
	{
		//appel à la Factory
		ArticlesDAO daoArticle = DAOFactory.getArticleDAO();
		
		//initialisation boolean pour le return
		boolean modifOk= false;
		
		try {
			
			//vérification des champs de l'article
			VerifArticle.champs(article);
			
			//appel à la méthode de modification de la DAL via la Factory
			daoArticle.update(article);
			modifOk = true;
			
		}catch(DALException e) {
			e.printStackTrace();
			throw new BllException("echec  mise a jour Article");
		}
		return modifOk;
	}
	
	/** récupère une liste d'articles en vente (EC), du plus récent au plus ancien
	 * @return liste d'articles demandée
	 */
	public static List<Articles> selectEcTriNoArticle()
	{
		//appel à la Factory
		ArticlesDAO manip = DAOFactory.getArticleDAO();
		
		//initialisation de la liste d'articles
		List<Articles> listeArticles = new ArrayList<Articles>();
		listeArticles = null;

		try {
			//appel à la méthode de select de la DAL via la Factory
			listeArticles = manip.selectEcTriNoArticle();
		} catch (DALException e) {
			e.printStackTrace();
		}
		return listeArticles;
	}
	
	/** récupère une liste d'articles en vente (EC) de la catégorie demandée, du plus récent au plus ancien
	 * @param noCategorie : numéro de la catégorie selectionée
	 * @return liste d'articles demandée
	 */
	public static List<Articles> selectEcEtCategorie(int noCategorie)
	{
		//appel à la Factory
		ArticlesDAO manip = DAOFactory.getArticleDAO();
		
		//initialisation de la liste d'articles
		List<Articles> listeArticles = new ArrayList<Articles>();
		listeArticles = null;

		try {
			//appel à la méthode de select de la DAL via la Factory
			listeArticles = manip.selectEcEtCategorie(noCategorie);
		} catch (DALException e) {
			e.printStackTrace();
		}
		return listeArticles;
	}
	
	/** récupère une liste d'articles en vente (EC) qui contient un mot clé, du plus récent au plus ancien
	 * @param motCle : mot clé recherché dans le nom de l'article
	 * @return liste d'articles demandée
	 */
	public static List<Articles> selectEcEtMot(String motCle)
	{
		//appel à la Factory
		ArticlesDAO manip = DAOFactory.getArticleDAO();
		
		//initialisation de la liste d'articles
		List<Articles> listeArticles = new ArrayList<Articles>();
		listeArticles = null;

		try {
			//appel à la méthode de select de la DAL via la Factory
			listeArticles = manip.selectEcEtMot(motCle);
		} catch (DALException e) {
			e.printStackTrace();
		}
		return listeArticles;
	}
	
	/** récupère une liste d'articles en vente (EC) de la catégorie demandée et qui contient un mot clé, du plus récent au plus ancien
	 * @param motCle : mot clé recherché dans le nom de l'article
	 * @param categorie : numéro de la catégorie selectionée
	 * @return liste d'articles demandée
	 */	
	public static List<Articles> selectEcEtMotEtCategorie(String motCle, int categorie)
	{
		//appel à la Factory
		ArticlesDAO manip = DAOFactory.getArticleDAO();
		
		//initialisation de la liste d'articles
		List<Articles> listeArticles = new ArrayList<Articles>();
		listeArticles = null;
		
		try {
			//appel à la méthode de select de la DAL via la Factory
			listeArticles = manip.selectEcEtMotEtCategorie(motCle, categorie);
		} catch (DALException e) {
			e.printStackTrace();
		}
		return listeArticles;
	}
		
	/** récupère une liste d'articles sélectioné par No de vendeur
	 * @param noVendeur : numéro du vendeur selectioné
	 * @return liste d'articles demandée
	 */	
	public static List<Articles> selectByNoVendeur(int noVendeur) throws DALException{
		
		//appel à la Factory
		ArticlesDAO manip = DAOFactory.getArticleDAO();
		
		//initialisation de la liste d'articles
		List<Articles> listeArticles = new ArrayList<Articles>();
		listeArticles = null;
		
		try {
			//appel à la méthode de select de la DAL via la Factory
			listeArticles = manip.selectByNoVendeur(noVendeur);
		} catch (DALException e) {
			e.printStackTrace();
		}
		return listeArticles;
	}

}
