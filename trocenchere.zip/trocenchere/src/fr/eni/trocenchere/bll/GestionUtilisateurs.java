package fr.eni.trocenchere.bll;
import fr.eni.trocenchere.dal.DAOFactory;
import fr.eni.trocenchere.dal.UtilisateurDAO;
import fr.eni.trocenchere.dal.DALException;
import java.sql.Connection;
import java.sql.PreparedStatement; 
import java.sql.ResultSet;
import java.sql.SQLException;

import fr.eni.trocenchere.bo.Utilisateurs;
import fr.eni.trocenchere.dal.ConnectionProvider;
import fr.eni.trocenchere.bll.verifications.VerifUtilisateur;

public class GestionUtilisateurs{

	
	public static Utilisateurs creationUtilisateur(String user) throws SQLException
	{
		UtilisateurDAO manip = DAOFactory.getUtilisateurDAO();
		Utilisateurs utilisateurRecherche;
		utilisateurRecherche = null;
		try {
			utilisateurRecherche = manip.selectByPseudo(user);
		} catch (DALException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return utilisateurRecherche;
	}
	
	
	
	
	public static Utilisateurs creationUtilisateur(int noUtilisateur) throws SQLException
	{
		UtilisateurDAO manip = DAOFactory.getUtilisateurDAO();
		Utilisateurs utilisateurRecherche;
		utilisateurRecherche = null;
		try {
			utilisateurRecherche = manip.selectByNoUtilisateur(noUtilisateur);
		} catch (DALException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return utilisateurRecherche;
	}

	
	/**
	 * insert un user dans la base de donn�e
	 * @param user utilisateur a inscrire
	 * @return vrai si l'utilisateur a bien �t� inscrit
	 * @throws SQLException
	 */
	public static boolean inscriptionUtilisateur(Utilisateurs user) throws SQLException, BllException
	{

		UtilisateurDAO manip = DAOFactory.getUtilisateurDAO();
		boolean bool= false;
		try {
		VerifUtilisateur.champs(user);
		manip.insert(user);
		bool = true;
		}catch(DALException e) {
			e.printStackTrace();
			throw new BllException("Champ(s) invalide(s) lors de l'inscription");
		}
		return bool;
		
	}
	/**
	 * Supprime un user de la base de donn�e
	 * @param no_utilisateur de l'utilisateur � supprimer
	 * @return vrai si l'utilisateur a bien �t� supprim�
	 */
	public static boolean suppressionUtilisateur(int no_utilisateur) throws SQLException,DALException{
		UtilisateurDAO manip = DAOFactory.getUtilisateurDAO();	
		if(manip.delete(no_utilisateur)) {
		return true;
		}else {return false;}
		
	}
	
	public static boolean modificationUtilisateur(Utilisateurs user) throws SQLException
	{
		UtilisateurDAO daoUtilisateur = DAOFactory.getUtilisateurDAO();
		boolean modifOk= false;
		
		try {
			VerifUtilisateur.champs(user);
			daoUtilisateur.update(user);
			modifOk = true;
		}catch(DALException e) {
			e.printStackTrace();
			throw new BllException("Champ(s) invalide(s) lors de la modification");
		}
		return modifOk;
	}
	
	
}
