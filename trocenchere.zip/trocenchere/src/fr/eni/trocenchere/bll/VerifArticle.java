package fr.eni.trocenchere.bll;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import fr.eni.trocenchere.bll.verifications.Verif;
import fr.eni.trocenchere.bo.Articles;
import fr.eni.trocenchere.bo.Utilisateurs;

public class VerifArticle {

	
	
			public static void champs(Articles article) throws BllException {
				String errmsg = "";
				
				
				
				//nom article
					if(	!Verif.rue(article.getNomArticle()) || !Verif.charMin(article.getNomArticle(),3)) 					
					{ errmsg+="Le nom de l'article ne doit pas contenir de caracteres speciaux et doit contenir au moins 3 caracteres <br/>";}
				//description - droit à tout
					
				//categorie 1 2 3 4
				if(article.getNoCategorie() == 0 )
				{ errmsg+= "Veuillez choisir une catégorie.";}
				//prix de départ
				if(article.getPrixInitial() < 0)
				{ errmsg+="Le prix de l'article ne doit pas être négatif <br/>";}
				
					
				//Date ouverture
				// Récupération date du jour en localdate (sans les heures)
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			    LocalDateTime now = LocalDateTime.now();
			    LocalDateTime dateOuverture = article.getDateDebutEnchere();
				    
				if(dateOuverture.isBefore(now))
				{ errmsg+="Date/heure d'ouverture non valide. Impossible de mettre une date/heure passée. <br/>";}
				
				//Heure d'ouverture
				
					
				//duree 3 5 7 ou 10

				
				//VERIFICATION ADRESSE DE RETRAIT
				
				
				
				//S'il y a des erreurs, alors cela lance l'exception
				if(errmsg != ""){
					throw new BllException(errmsg);
					}
				
				
				
			}
}
