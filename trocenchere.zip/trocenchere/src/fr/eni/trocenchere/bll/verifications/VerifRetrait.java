package fr.eni.trocenchere.bll.verifications;

import fr.eni.trocenchere.bll.BllException;
import fr.eni.trocenchere.bo.Retraits;

public class VerifRetrait {

	public static void champs(Retraits retrait) throws BllException {
	String errRetrait = "";
	
		if(	!Verif.rue(retrait.getRue()) || !Verif.charMax(retrait.getRue(),50)) 				
		{ errRetrait+="La rue ne doit pas contenir de caracteres speciaux et doit contenir moins de 50 caracteres <br/>";}
		if(	!Verif.num(retrait.getCode_postal()) || !Verif.nbChar(retrait.getCode_postal(), 5)) 		
		{ errRetrait+="Le code postal de l'utilisateur doit contenir 5 chiffres <br/>";}
		if( !Verif.ville(retrait.getVille()) || !Verif.charMax(retrait.getVille(), 50))					
		{errRetrait+="La ville de l'utilisateur ne doit contenir que des lettres et doit contenir moins de 50 caracteres <br/>";}
	
	//S'il y a des erreurs, alors cela lance l'exception
	if(errRetrait != ""){
		throw new BllException(errRetrait);
		}

	
	
	}
	
	
	
}
