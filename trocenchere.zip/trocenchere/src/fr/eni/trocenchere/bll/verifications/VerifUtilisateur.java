package fr.eni.trocenchere.bll.verifications;
import fr.eni.trocenchere.bo.Utilisateurs;
import fr.eni.trocenchere.dal.DALException;
import fr.eni.trocenchere.dal.DAOFactory;
import fr.eni.trocenchere.dal.UtilisateurDAO;

import java.sql.SQLException;

import fr.eni.trocenchere.bll.BllException;

public class VerifUtilisateur {
	
	
	public static void champs(Utilisateurs user) throws BllException {
		String err="";
		if(	!Verif.nomPrenom(user.getNom()) || !Verif.charMin(user.getNom(),3)) 					
		{ err+="Le nom de l'utilisateur ne doit contenir que des lettres et doit contenir au moins 3 caracteres <br/>";}
		if(	!Verif.nomPrenom(user.getPrenom()) || !Verif.charMin(user.getNom(),3)) 				
		{ err+="Le prenom de l'utilisateur ne doit contenir que des lettres et doit contenir au moins 3 caracteres <br/>"; }
		if(	!Verif.mail(user.getEmail()) || !Verif.charMax(user.getEmail(),20))														 	
		{ err+="L'adresse mail de l'utilisateur doit contenir moins de 20 caracteres <br/>";}
		if(	(!Verif.num(user.getTelephone()) || !Verif.nbChar(user.getTelephone(),10)) && user.getTelephone()!="")			
		{ err+="Le numero de telephone doit contenir 10 chiffres <br/>";}
		if(	!Verif.rue(user.getRue()) || !Verif.charMax(user.getRue(),50)) 				
		{ err+="L'adresse ne doit pas contenir de caracteres speciaux et doit contenir moins de 50 caracteres <br/>";}
		if(	!Verif.num(user.getCode_postal()) || !Verif.nbChar(user.getCode_postal(), 5)) 		
		{ err+="Le code postal de l'utilisateur doit contenir 5 chiffres <br/>";}
		if( !Verif.ville(user.getVille()) || !Verif.charMax(user.getVille(), 50))					
		{err+="La ville de l'utilisateur ne doit contenir que des lettres et doit contenir moins de 50 caracteres <br/>";}
		if(	!Verif.charMin(user.getMot_de_passe(),8))													
		{ err+="Le mot de passe doit contenir au moins 8 caracteres <br/>";}
		
		if(err != ""){
		throw new BllException(err);
		}
	}
	
	public static boolean userExiste(Utilisateurs utilisateurTest) throws SQLException
	{
		boolean testUser = false;
		
		if(utilisateurTest != null)
		{
			testUser = true;
		}else {
			System.err.println("erreur : utilisateur = null");
			//FIXME faire exception
		}
		return testUser;
	}
	
	public static boolean mdpOk (Utilisateurs utilisateurTest, String mdpATestser) throws SQLException
	{
		boolean testMdp = false;
		
		if(mdpATestser.equals(utilisateurTest.getMot_de_passe()))
		{
			testMdp = true;
		}else {
			System.err.println("erreur : mÃ©thode mdpOk");
			//FIXME faire exception
		}
		return testMdp;
	}
	
	
	public static boolean identificationOk(String pseudo, String mdpATestser) throws SQLException
	{
		boolean testOk = false;
		boolean testUser = false;
		boolean testMdp = false;
		
		UtilisateurDAO daoUtilisateur = DAOFactory.getUtilisateurDAO();
		Utilisateurs utilisateurTest = null;
		
		try {
			utilisateurTest = daoUtilisateur.selectByPseudo(pseudo);
		} catch (DALException e) {
			e.printStackTrace();
		}
		
		testUser = userExiste(utilisateurTest);
		
		if (testUser)
		{
			testMdp = mdpOk(utilisateurTest, mdpATestser);
			
			if (testMdp)
			{
				testOk = true;
			}else {
				System.err.println("erreur : mot de passe incorect");
			}
			
		}else {
			System.err.println("erreur : user existe pas dans la base");
		}
		//FIXME faire exception
		
		return testOk;
	}
	
	
	
	
	
}
