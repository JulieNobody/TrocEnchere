package fr.eni.trocenchere.bll.verifications;
import java.text.Normalizer;

public abstract class Verif {

/**
 * Verifie qu'une cdc ne contient pas de caracteres sp�ciaux
 * @param sample : cdc a verifier
 * @return vrai si la cdc ne contient que des chiffres et des lettres , faux sinon
 */
	public static boolean alphaNum(String sample) {
		 String regExpression = "[a-zA-Z_0-9]*";
		 return sample.matches(regExpression);
	}
	/**
	 * Verifie qu'une cdc ne contient que des chiffres
	 * @param sample : cdc a verifier
	 * @return vrai si la cdc ne contient que des chiffres , faux sinon
	 */
	public static boolean num(String sample) {
		 String regExpression = "[0-9]*";
		 return sample.matches(regExpression);
	}
	
	/**
	 * Verifie qu'une cdc ne contient que des lettres
	 * @param sample : cdc a verifier
	 * @return vrai si la cdc ne contient que des lettres , faux sinon
	 */
	public static boolean alpha(String sample) {
		String regExpression = "[a-z- 'A-Z]*";
		 return sample.matches(regExpression);
	}
	
	public static boolean nomPrenom(String sample) {
		 String regExpression = "[a-z -'A-Z]*";
		 String temp=Normalizer.normalize(sample, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
		 return temp.matches(regExpression);
	}
	public static boolean mail(String sample) {
		 String regExpression = "[a-z_.-@A-Z_0-9]*";
		 String at = "@";
		 if(sample.contains(at)) {
		 return sample.matches(regExpression);}
		 else {return false;}
	}
	public static boolean rue(String sample) {
		 String regExpression = "[a-z' -/A-Z_0-9]*";
		 String temp=Normalizer.normalize(sample, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
		 return temp.matches(regExpression);
	}
	public static boolean ville(String sample) {
		 String regExpression = "[a-z'/ A-Z]*";
		 String temp=Normalizer.normalize(sample, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
		 return temp.matches(regExpression);
	}
	
	
	
	
	
	
	
/**
 * Verifie qu'une cdc contient nb caracteres exactement
 * @param sample : cdc a verifier
 * @param nb :nombre de carac�res voulu dans la cdc
 * @return vrai si la cdc contient nb caract�res, faux sinon
 */
	public static boolean nbChar(String sample, int nb) {
		if(sample.length()==nb) {
			return true;
		}else {return false;}
	}
	/**
	 * Verifie qu'une cdc contient au moins nb caract�res
	 * @param sample : cdc a verifier
	 * @param min :nombre de carac�res minimum voulu dans la cdc
	 * @return vrai si la cdc contient au moins min caract�res, faux sinon
	 */
	public static boolean charMin(String sample, int min) {
		if(sample.length()<min) {
			return false;
		}else {return true;}
	}
	/**
	 * Verifie qu'une cdc contient au moins nb caract�res
	 * @param sample : cdc a verifier
	 * @param max :nombre de carac�res maximum voulu dans la cdc
	 * @return vrai si la cdc contient moins de max caract�res, faux sinon
	 */
	public static boolean charMax(String sample, int max) {
		if(sample.length()>max) {
			return false;
		}else {return true;}
	}
	
}
