
package fr.eni.trocenchere.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fr.eni.trocenchere.bll.BllException;
import fr.eni.trocenchere.bll.Format;
import fr.eni.trocenchere.bll.GestionArticles;
import fr.eni.trocenchere.bll.GestionRetraits;
import fr.eni.trocenchere.bo.Articles;
import fr.eni.trocenchere.bo.Retraits;
import fr.eni.trocenchere.bo.Utilisateurs;

/**
 * Servlet implementation class VenteArticleServlet
 */
@WebServlet("/VenteArticleServlet")
public class VenteArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String errMsg=null;
		if(request.getAttribute("errMsg") == null) {

				 errMsg = "";
				 request.setAttribute("errMsg",errMsg);
			
		}
		
		LocalDate localDate = LocalDate.now();
		request.setAttribute("date", localDate);
		
		Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);
        
        if(minute>=50) {
        	minute = minute -50;
        	hour = hour + 1;
        }else if(minute<50 ) {
        	minute = minute +10;
        }
     
        if(hour < 10 && minute < 10) {
        	request.setAttribute("time", ("0" + hour + ":0" + minute));
        } else if(hour < 10 && minute >= 10 ) {
        	request.setAttribute("time", ("0" + hour + ":" + minute));
        } else if (hour >= 10 && minute < 10) {
        	request.setAttribute("time", (hour + ":0" + minute));
        } else if (hour >= 10 && minute >= 10) {
        	request.setAttribute("time", (hour + ":" + minute));
        }
        
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/jsp/VenteArticle.jsp");
		rd.forward(request, response);
	}


	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String errMsg="";
		request.setAttribute("errMsg",errMsg);
		HttpSession session = request.getSession();
		Utilisateurs utilisateur =  (Utilisateurs) session.getAttribute("cetUtilisateur");
        
		// R�cup�ration de la date et de l'heure  de d�but
		LocalDateTime dateDebutEnchere = null;
		String dateDebut=null;
		String dateDebutTime=null;
		try {
			 dateDebut = request.getParameter("dateDebutEnchere");
			 dateDebutTime = request.getParameter("dateheuredebut");
		//Conversion des deux param�tre en un seul	
			dateDebutEnchere = Format.convertStringToLocalDateTime(dateDebut + " " + dateDebutTime);
		}catch (DateTimeException e) {
			e.printStackTrace();
		}
		if(dateDebut.equals("") || dateDebutTime.equals("")) {
			errMsg="Les champs de date et d'heure de début d'enchère sont obligatoires";
			request.setAttribute("errMsg",errMsg);
			doGet(request, response);
			}else {
	//Ajout de la dur�e choisie pour d�terminer la date de fin de l'enchere
		//On r�cup�re la dur�e choisie
		String dureeEnString = request.getParameter("duree");
		int duree = Integer.parseInt(dureeEnString);
		
		LocalDateTime dateFinEnchere = dateDebutEnchere.plusDays(duree);
		
		//PrixInitial en int 
		int prixInitial = Integer.parseInt(request.getParameter("prixInitial"));
		
		//Num�ro cat�gorie en int 
		
		String noCategorieString = request.getParameter("noCategorie");
			
		int noCategorie = Integer.parseInt(noCategorieString);
		
		Articles article = new Articles(
				request.getParameter("nomArticle"),
				request.getParameter("description"),
				dateDebutEnchere,
				dateFinEnchere,
				prixInitial,
				//Le prix de vente est de 0 pour l'instant puisque l'enchere vient d'�tre cr��e
				prixInitial,
				(int)utilisateur.getNo_utilisateur(),
				noCategorie,
				"CR",
				"image" ); 
				
	
		
		try {
			
				if(GestionArticles.inscriptionArticle(article) ) {
					
					
					Retraits retraits = new Retraits(
							article.getNoArticle(),
							request.getParameter("rueRetrait"),
							request.getParameter("cpRetrait"),
							request.getParameter("villeRetrait"));
					
						if(GestionRetraits.inscriptionRetrait(retraits)) {
							response.sendRedirect(request.getContextPath() + "/AfficheArticle" +"?noArticle=" + article.getNoArticle());
							//RequestDispatcher rd = request.getRequestDispatcher("/AfficheArticle" +"?noArticle=" + article.getNoArticle() );
							
							//rd.forward(request, response);
						}
				}
		}  catch (SQLException e) {
			e.printStackTrace();
			System.out.println("BONJOUR SQL EXCEPTION");
		}catch (BllException e) {
			System.out.println("erreur attrapée article");
			request.setAttribute("errMsg",e.getMessage());
			
			doGet(request, response);
		}
	
		
		
		}
		
		
		}
		
}


