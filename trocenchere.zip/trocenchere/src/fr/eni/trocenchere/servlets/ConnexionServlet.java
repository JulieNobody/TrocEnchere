package fr.eni.trocenchere.servlets;

import java.io.IOException;  
import java.sql.SQLException;
import javax.servlet.http.Cookie;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import fr.eni.trocenchere.bll.GestionUtilisateurs;
import fr.eni.trocenchere.bll.verifications.VerifUtilisateur;
import fr.eni.trocenchere.bo.Utilisateurs;
import fr.eni.trocenchere.dal.DALException;
import fr.eni.trocenchere.dal.DAOFactory;
import fr.eni.trocenchere.dal.UtilisateurDAO;


@WebServlet("/connexion")
public class ConnexionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet");
		String errMsg = "";
		request.setAttribute("errMsg", errMsg);
		String resterConnecte = getCookieValue(request,"resterConnecte");
		 HttpSession session = request.getSession();
		if(resterConnecte!=null) {
			try {				
				session.setAttribute("cetUtilisateur",GestionUtilisateurs.creationUtilisateur( Integer.parseInt(resterConnecte)));
				}catch(SQLException e) {
					e.printStackTrace();
				}
			request.setAttribute("unUtilisateur", session.getAttribute("cetUtilisateur"));
			response.sendRedirect(request.getContextPath() + "/accueil");
		     
		}else {
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/jsp/connexion.jsp");
		rd.forward(request, response);
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("name");
		String mdp = request.getParameter("mdp");

	
		Utilisateurs cetUtilisateur = null;
		
		
		
		try {
			
			if(VerifUtilisateur.identificationOk(id,mdp))
			{
				cetUtilisateur = GestionUtilisateurs.creationUtilisateur(id);
			
				
		        HttpSession session = request.getSession();
		        session.setAttribute("cetUtilisateur", cetUtilisateur);

				
		        /* Si et seulement si la case du formulaire est cochée */
			    if ( request.getParameter( "remember" ) != null ) {

			    	String resterConnecte =String.valueOf(cetUtilisateur.getNo_utilisateur());
			    	System.out.println("resterConnecte: "+resterConnecte);
			        /* Création du cookie, et ajout à la réponse HTTP */
			        setCookie( response, "resterConnecte", resterConnecte, 365*24*60*60 );
			    } else {
			        /* Demande de suppression du cookie du navigateur */
			        setCookie( response, "resterConnecte", "", 0 );
			    }
				
				request.setAttribute("unUtilisateur", cetUtilisateur);
				response.sendRedirect(request.getContextPath() + "/accueil");
				
				
			}else {
				
				request.setAttribute("message", "Attention, login ou mot de passe incorrect");
				
				RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/jsp/connexion.jsp");
				rd.forward(request, response);
			}
			
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
    /**
     * Méthode utilitaire gérant la récupération de la valeur d'un cookie donné
     * depuis la requête HTTP.
     */
    private static String getCookieValue( HttpServletRequest request, String nom ) {
        Cookie[] cookies = request.getCookies();
        if ( cookies != null ) {
        	
            for ( Cookie cookie : cookies ) {
                if ( cookie != null && nom.equals( cookie.getName() ) ) {
                    return cookie.getValue();
                }
            }
        }

        return null;
    }

    
    /*
     * Méthode utilitaire gérant la création d'un cookie et son ajout à la
     * réponse HTTP.
     */
    private static void setCookie( HttpServletResponse response, String nom, String valeur, int maxAge ) {
        Cookie cookie = new Cookie( nom, valeur );
        cookie.setMaxAge( maxAge );
        response.addCookie( cookie );
    }
    
}
