package fr.eni.trocenchere.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import fr.eni.trocenchere.dal.DALException;
import fr.eni.trocenchere.bll.GestionUtilisateurs;
import fr.eni.trocenchere.bo.Utilisateurs;

/**
 * Servlet implementation class suppressionCompte
 */
@WebServlet("/suppressionCompte")
public class suppressionCompte extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws  ServletException,IOException {
		
		 HttpSession session = request.getSession();
		 Utilisateurs user=(Utilisateurs)session.getAttribute("cetUtilisateur");
		 if(user != null)
		 {		try {
			if(GestionUtilisateurs.suppressionUtilisateur(user.getNo_utilisateur())){
				session.removeAttribute("logonSessData");
			    session.invalidate(); 
				RequestDispatcher rd = request.getRequestDispatcher("accueil");
				request.setAttribute("message", "Le compte a été supprimé");
				rd.forward(request, response);
			}else {
				RequestDispatcher rd = request.getRequestDispatcher("accueil");
				request.setAttribute("message", "Le compte n'a pas été supprimé");
				rd.forward(request, response);
			}
			}catch(SQLException e)
			{
				RequestDispatcher rd = request.getRequestDispatcher("suppressionCompte");
				request.setAttribute("message","La suppression de compte a échouée");
				rd.forward(request, response);
				e.printStackTrace();
				
			}
		catch(DALException e) {
			RequestDispatcher rd = request.getRequestDispatcher("suppressionCompte");
			request.setAttribute("message","La suppression de compte a échouée");
			rd.forward(request, response);
		}
		 }else {
			 RequestDispatcher rd = request.getRequestDispatcher("accueil");
				rd.forward(request, response);
		 }

	}

}
