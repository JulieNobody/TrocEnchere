package fr.eni.trocenchere.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.time.DateTimeException;
import java.time.LocalDateTime;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fr.eni.trocenchere.bll.BllException;
import fr.eni.trocenchere.bll.Format;
import fr.eni.trocenchere.bll.GestionArticles;
import fr.eni.trocenchere.bll.GestionRetraits;
import fr.eni.trocenchere.bo.Articles;
import fr.eni.trocenchere.bo.Retraits;
import fr.eni.trocenchere.bo.Utilisateurs;

/**
 * Servlet implementation class ModificationArticle
 */
@WebServlet("/ModificationArticle")
public class ModificationArticle extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String errMsg=null;
		if(request.getAttribute("errMsg") == null) {

				 errMsg = "";
				 request.setAttribute("errMsg",errMsg);
			
		}
		String param = request.getParameter("noArticle").trim();
		int idArticle = Integer.parseInt(param);
		Articles article=null;
		try {
		 article = GestionArticles.creationArticle(idArticle);
		System.out.println(article.toString());
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("errMsg",errMsg);
		HttpSession session = request.getSession();
		session.setAttribute("article",article);
		
		//passage en string et separation de la date et de l'heure de debut d'enchere pour preremplissage des champs
		String dateHeure=String.valueOf(article.getDateDebutEnchere());
		String dateHeureTab[]= dateHeure.split("T");

		request.setAttribute("date",dateHeureTab[0]);
		request.setAttribute("time",dateHeureTab[1]);
		
		session.getAttribute("cetUtilisateur");
		
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/jsp/ModificationArticle.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String errMsg="";
		request.setAttribute("errMsg",errMsg);
		HttpSession session = request.getSession();
		Utilisateurs utilisateur =  (Utilisateurs) session.getAttribute("cetUtilisateur");
        
		// R�cup�ration de la date et de l'heure  de d�but
		LocalDateTime dateDebutEnchere = null;
		String dateDebut="";
		String dateDebutTime="";
		try {
			 dateDebut = request.getParameter("dateDebutEnchere");
			 dateDebutTime = request.getParameter("dateheuredebut");
		//Conversion des deux param�tre en un seul	
			dateDebutEnchere = Format.convertStringToLocalDateTime(dateDebut + " " + dateDebutTime);
		}catch (DateTimeException e) {
			e.printStackTrace();
		}
		
		if(dateDebut.equals("") || dateDebutTime.equals("")) {
			errMsg="Les champs de date et d'heure de début d'enchère sont obligatoires";
			request.setAttribute("errMsg",errMsg);
			doGet(request, response);
			}else {
		
	//Ajout de la dur�e choisie pour d�terminer la date de fin de l'enchere
		//On r�cup�re la dur�e choisie
		String dureeEnString = request.getParameter("duree");
		int duree = Integer.parseInt(dureeEnString);
		
		LocalDateTime dateFinEnchere = dateDebutEnchere.plusDays(duree);
		
		//PrixInitial en int 
		int prixInitial = Integer.parseInt(request.getParameter("prixInitial"));
		
		//Num�ro cat�gorie en int 
		
		String noCategorieString = request.getParameter("noCategorie");
			
		int noCategorie = Integer.parseInt(noCategorieString);
		
		Articles article = new Articles(
				Integer.parseInt(request.getParameter("noArticle")),
				request.getParameter("nomArticle"),
				request.getParameter("description"),
				dateDebutEnchere,
				dateFinEnchere,
				prixInitial,
				prixInitial,
				(int)utilisateur.getNo_utilisateur(),
				noCategorie,
				"CR",
				"image" ); 
				
	
		
		try {
			
				if(GestionArticles.modificationArticle(article) ) {
					
					
					Retraits retraits = new Retraits(
							article.getNoArticle(),
							request.getParameter("rueRetrait"),
							request.getParameter("cpRetrait"),
							request.getParameter("villeRetrait"));
					
						if(GestionRetraits.modificationRetrait(retraits)) {
							response.sendRedirect(request.getContextPath() + "/AfficheArticle" +"?noArticle=" + article.getNoArticle());
							//RequestDispatcher rd = request.getRequestDispatcher("/AfficheArticle" +"?noArticle=" + article.getNoArticle() );
							
							//rd.forward(request, response);
						}else {response.sendRedirect(request.getContextPath() + "/AfficheArticle" +"?noArticle=" + article.getNoArticle());}
				}
		}  catch (SQLException e) {
			e.printStackTrace();
			System.out.println("BONJOUR SQL EXCEPTION");
		}catch (BllException e) {
			System.out.println("erreur attrapée article");
			request.setAttribute("errmsg",e.getMessage());
			
			
		}

		
			}
	}

}
