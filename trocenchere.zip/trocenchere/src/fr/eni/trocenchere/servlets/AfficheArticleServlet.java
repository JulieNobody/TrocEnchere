package fr.eni.trocenchere.servlets;

import java.io.IOException; 
import java.sql.SQLException;
import java.time.LocalDateTime;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fr.eni.trocenchere.bll.*;
import fr.eni.trocenchere.bo.Articles;
import fr.eni.trocenchere.bo.Encheres;
import fr.eni.trocenchere.bo.Utilisateurs;
import fr.eni.trocenchere.dal.ArticlesDAO;
import fr.eni.trocenchere.dal.DALException;
import fr.eni.trocenchere.dal.DAOFactory;
import fr.eni.trocenchere.dal.UtilisateurDAO;
import fr.eni.trocenchere.dal.UtilisateurDAOJdbcImpl;

/**Servlet AfficheArticle
 * affiche le détail d'un article passé en URL
 * affichage différent selon profil visiteur
 */
@WebServlet("/AfficheArticle")
public class AfficheArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//gestion des erreurs
		String errMsg="";
		request.setAttribute("errMsg",errMsg);
		
		
		//instanciation des états de vente
			/*ETATS VENTE
			CR - crée
			EC - en cours
			VD - vendu
			RT - retirer*/
		request.setAttribute("CR", "CR");
		request.setAttribute("EC", "EC");
		request.setAttribute("VD", "VD");
		request.setAttribute("RT", "RT");
		
		try {
			//récupération de l'id de l'article dans l'URL et passage de la valeur de String à int
			String param = request.getParameter("noArticle").trim();
			
			int idArticle = Integer.parseInt(param);
			System.out.println("Id Article : " + idArticle);
			
			//récupération de l'article dans la BDD by le No d'article
			Articles article = GestionArticles.creationArticle(idArticle);
			
			//récupération du vendeur par l'article (No d'utilisateur)
			Utilisateurs vendeurArticle = GestionUtilisateurs.creationUtilisateur(article.getNoVendeur());

			//passage de l'article et du vendeur à la JSP
			request.setAttribute("vendeurArticle", vendeurArticle);
			request.setAttribute("cetArticle", article);
						
			//récupération de l'utilisateur de la session et envoi vers JSP
			HttpSession session = request.getSession();
			session.getAttribute("cetUtilisateur");
									
		} catch ( SQLException e) {
			e.printStackTrace();
		}

		//redirection vers la JSP AfficheArticle.jsp.jsp
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/jsp/AfficheArticle.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String errMsg="";
		int bourse=0;
		Utilisateurs user=(Utilisateurs)session.getAttribute("cetUtilisateur");
		int noArt=Integer.parseInt(request.getParameter("noArticle"));
		
		int montant= Integer.parseInt((String)request.getParameter("montant"));
		Encheres enchere= new Encheres(user.getNo_utilisateur(),noArt,LocalDateTime.now(),montant);
		
		
		Encheres ancienneEnchere= new Encheres();
		UtilisateurDAOJdbcImpl manip =  new UtilisateurDAOJdbcImpl();
		try {
			Articles art=GestionArticles.creationArticle(noArt);
			//Si l'enchere est assez haute
			if(enchere.getMontantEnchere()>art.getPrixVente()) {
				//Si il y avait déjà une enchere
				if(ancienneEnchere.getMontantEnchere()>0) {
					//il faut redonner son argent au precedent enchereur
					Utilisateurs dernierEnchereur= manip.selectByNoUtilisateur(ancienneEnchere.getNoAcheteur());
					bourse=dernierEnchereur.getCredit();
					dernierEnchereur.setCredit(bourse+ancienneEnchere.getMontantEnchere());
					GestionUtilisateurs.modificationUtilisateur(dernierEnchereur);
				}else {/*il n'y avait pas encore d'enchere*/}
				//Si l'utilisateur a suffisament de crédits
				if(user.getCredit()> enchere.getMontantEnchere()) {
					bourse=user.getCredit();
					//L'utilisateur perd le montant de crédit egal a l'enchere
					user.setCredit(bourse-enchere.getMontantEnchere());
					GestionUtilisateurs.modificationUtilisateur(user);
				
					ancienneEnchere=GestionEncheres.creationEnchere(enchere);
					art.setPrixVente(enchere.getMontantEnchere());
					GestionArticles.modificationArticle(art);
					
					enchere.setNoAcheteur(user.getNo_utilisateur()); //L'utilisateur est désigné acheteur sur l'enchere
				}else {/*Pas assez de crédits*/ 
					errMsg+="Vous n'avez pas assez de crédits (CHEH)<br/>";
					}
			}else {/*Enchere trop basse*/
				errMsg+="Votre enchere est trop basse, veuillez actualiser la page et mettre une enchère supérieure au prix actuel <br/>";}
			request.setAttribute("errMsg",errMsg);
			System.out.println("errsMsg: "+ errMsg);
		}catch(DALException e) {
			e.printStackTrace();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
	
		doGet(request, response);
	}

}
