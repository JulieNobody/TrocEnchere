package fr.eni.trocenchere.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fr.eni.trocenchere.bll.GestionUtilisateurs;
import fr.eni.trocenchere.bll.verifications.Verif;
import fr.eni.trocenchere.bo.Utilisateurs;

/** Servlet ModificationProfil
 *affichage des données de l'utilisateur conecté (en session) dans des champs de modification
 */
@WebServlet("/ModificationProfil")
public class ModificationProfilServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//gestion des erreurs
		String errMsg="";
		request.setAttribute("errMsg",errMsg);
		
		//récupération de l'utilisateur dans la session
		HttpSession session = request.getSession();
		session.getAttribute("cetUtilisateur");
		
		//redirection vers la JSP ModificationProfil.jsp
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/jsp/ModificationProfil.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//gestion des erreurs
		String errMsg="";
		request.setAttribute("errMsg",errMsg);
		
		//gestion encodage des champs	
		request.setCharacterEncoding("UTF-8");
		
		//récupération de l'utilisateur
		HttpSession session = request.getSession();
		Utilisateurs cetUtilisateur=(Utilisateurs)session.getAttribute("cetUtilisateur");
		
		//récupération des champs de la JSP	et création d'un Utilisateur "user"
		Utilisateurs user = new Utilisateurs(
				userTemp.getNo_utilisateur(),
				request.getParameter("pseudo"),
				request.getParameter("lastname"),
				request.getParameter("firstname"),
				request.getParameter("email"),
				request.getParameter("phone"),
				request.getParameter("street"),
				request.getParameter("zipcode"),
				request.getParameter("city"),
				request.getParameter("password"),
				cetUtilisateur.getCredit(),
				false);
		try {
			//mise à jour de l'utilisateur en BDD
			if(GestionUtilisateurs.modificationUtilisateur(user)){
				
				//récupération de l'utilisateur mis à jour via la BDD
				user = GestionUtilisateurs.creationUtilisateur(user.getPseudo());
							
				//mise à jour des données de l'utilsateur connecté
			    session.setAttribute("cetUtilisateur", user);
				request.setAttribute("unUtilisateur", user);
				
				//redirection vers la JSP ModificationProfil.jsp
				RequestDispatcher rd = request.getRequestDispatcher("/AffichageProfil");
				rd.forward(request, response);
			}else {
				e.printStackTrace();
			}
		
		}catch(SQLException e)
		{
			e.printStackTrace();			
		}
	}

}
