package fr.eni.trocenchere.servlets;

import java.io.IOException; 
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fr.eni.trocenchere.bll.GestionArticles;
import fr.eni.trocenchere.bll.GestionUtilisateurs;
import fr.eni.trocenchere.bo.Articles;
import fr.eni.trocenchere.bo.Utilisateurs;

/**Servlet accueil
 * affichage de liste d'articles et champs de recherche
 */
@WebServlet("/accueil")
public class Accueil extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//gestion des erreurs
		String errMsg="";
		request.setAttribute("errMsg",errMsg);
		
		//récuprération des articles en vente (EC), du plus récent au plus ancien
		List<Articles> listeArticles = GestionArticles.selectEcTriNoArticle();
		
		//récupération du pseudo du vendeur (en fonction de son numéro, dans l'instance d'article)
		List<Utilisateurs> listeUtilisateurs = new ArrayList<Utilisateurs>();
	 	
		 try {
			for(Articles article : listeArticles){
		        int numeroVendeur = article.getNoVendeur();

				Utilisateurs user = GestionUtilisateurs.creationUtilisateur(numeroVendeur);
				listeUtilisateurs.add(user);	  
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}			
		
		//envoi des articles et des utilisateurs (pseudos) à la JSP
		request.setAttribute("listeUtilisateurs", listeUtilisateurs);
		request.setAttribute("listeArticles", listeArticles);
		
		//redirection vers la JSP accueil.jsp
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/jsp/Accueil.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//gestion des erreurs
		String errMsg="";
		
		//gestion encodage des champs		
		request.setCharacterEncoding("UTF-8");
		
		//gestion des champs de recherches		
		String motCle = "";
		int categorie = 0;
		List<Articles> listeArticles = null;
		
		//récupération des champs de la JSP	
		motCle = request.getParameter("motCle");
		categorie = Integer.parseInt(request.getParameter("categorie"));
		
		//si les champs de recherche sont vide : affichage des articles en vente (EC), du plus récent au plus ancien
		if (motCle.equals("") && categorie == 0) {
			listeArticles = GestionArticles.selectEcTriNoArticle();
		}
		
		//si un mot clé est saisi mais pas de catégorie : affichage des articles en vente (EC) où le mot clé apparrait
		if (!motCle.equals("") && categorie == 0)
		{
			listeArticles = GestionArticles.selectEcEtMot(motCle);
		}
		
		//si une catégorie est choisie mais aucun de mot clé n'est saisi : affichage des articles en vente (EC) de la catégorie selectionée
		if (categorie != 0 && motCle.equals(""))
		{
			listeArticles = GestionArticles.selectEcEtCategorie(categorie);
		}
		
		//si un mot clé est saisi et qu'une catégorie est choisie: affichage des articles en vente (EC) de la catégorie selectionée où le mot clé apparrait
		if (categorie != 0 && !motCle.equals(""))
		{
			listeArticles = GestionArticles.selectEcEtMotEtCategorie(motCle, categorie);
		}
		
		//message si la liste d'article retournée est vide
		if (listeArticles.size() == 0)	{
			errMsg = "Aucun article ne correspond à votre recherche";
			}
		
		//récupération du pseudo du vendeur (en fonction de son numéro, dans l'instance d'article)
		List<Utilisateurs> listeUtilisateurs = new ArrayList<Utilisateurs>();
	 	
		 try {
			for(Articles article : listeArticles){
				 int numeroVendeur = article.getNoVendeur();
		         System.out.println(numeroVendeur);
		         Utilisateurs user = GestionUtilisateurs.creationUtilisateur(numeroVendeur);
		         listeUtilisateurs.add(user);	  
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		 
		//envoi des articles, des utilisateurs (pseudos) et message d'erreur à la JSP
		request.setAttribute("listeArticles", listeArticles);
		request.setAttribute("listeUtilisateurs", listeUtilisateurs);
		request.setAttribute("errMsg",errMsg);
		
		//redirection vers la JSP accueil.jsp
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/jsp/Accueil.jsp");
		rd.forward(request, response);
	}
}