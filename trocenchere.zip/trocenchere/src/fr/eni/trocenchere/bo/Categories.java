package fr.eni.trocenchere.bo;

import java.time.LocalDate;

public class Categories {

	//---------------------- ATTRIBUTS ----------------------
	private int noCategorie;
	private String libelle;

		
	//---------------------- CONSTRUCTEUR ----------------------
		
	public Categories(int noCategorie, String libelle)
	{
		this.noCategorie = noCategorie;
		this.libelle = libelle;
	}

	
	//---------------------- GETTER / SETTER ----------------------
	
	public int getNoCategorie() {
		return noCategorie;
	}

	public void setNoCategorie(int noCategorie) {
		this.noCategorie = noCategorie;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	
	//---------------------- TOSTRING ----------------------
	
	@Override
	public String toString() {
		return "Categories [noCategorie=" + noCategorie + ", libelle=" + libelle + "]";
	}
	
	
}
