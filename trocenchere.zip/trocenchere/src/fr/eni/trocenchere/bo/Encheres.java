package fr.eni.trocenchere.bo;

import java.time.LocalDateTime;

public class Encheres {

	//---------------------- ATTRIBUTS ----------------------
	private int noAcheteur;
	private int noArticle;
	private LocalDateTime dateEnchere;
	private int montantEnchere;
		
	//---------------------- CONSTRUCTEUR ----------------------
	/** constructeur d'Encheres complet */	
	public Encheres(int noAcheteur, int noArticle, LocalDateTime dateEnchere, int montantEnchere) {
		this.noAcheteur = noAcheteur;
		this.noArticle = noArticle;
		this.dateEnchere = dateEnchere;
		this.montantEnchere = montantEnchere;
	}
	
	/** constructeur d'Encheres vide */
	public Encheres() {
	}
	
	//---------------------- GETTER / SETTER ----------------------
	public int getNoAcheteur() {
		return noAcheteur;
	}

	public void setNoAcheteur(int noAcheteur) {
		this.noAcheteur = noAcheteur;
	}

	public int getNoArticle() {
		return noArticle;
	}

	public void setNoArticle(int noArticle) {
		this.noArticle = noArticle;
	}

	public LocalDateTime getDateEnchere() {
		return dateEnchere;
	}

	public void setDateEnchere(LocalDateTime dateEnchere) {
		this.dateEnchere = dateEnchere;
	}

	public int getMontantEnchere() {
		return montantEnchere;
	}

	public void setMontantEnchere(int montantEnchere) {
		this.montantEnchere = montantEnchere;
	}
	
	//---------------------- TOSTRING ----------------------
	@Override
	public String toString() {
		return "Encheres [noAcheteur=" + noAcheteur + ", noArticle=" + noArticle + ", dateEnchere=" + dateEnchere
				+ ", montantEnchere=" + montantEnchere + "]";
	}	
	
}
