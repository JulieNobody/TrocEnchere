package fr.eni.trocenchere.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import fr.eni.trocenchere.bo.Encheres;
import fr.eni.trocenchere.bo.Retraits;

public class RetraitsDAOJdbcImpl implements RetraitsDAO{

	public static final String SELECTBYNOARTICLE = "SELECT * FROM dbo.RETRAITS WHERE no_article=?";
	public static final String INSERT = "INSERT INTO dbo.RETRAITS ( no_article, rue, code_postal, ville) VALUES(?,?,?,?)";
	
	
	
	
	
	
	
	
	@Override
	public Retraits selectByNoArticle(int noArticle) throws DALException {
		Retraits retrait = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try(Connection cnx = ConnectionProvider.getConnection())
		{
			
			stmt = cnx.prepareStatement(SELECTBYNOARTICLE);
			stmt.setInt(1, noArticle);
		
			rs = stmt.executeQuery();

			

			if(rs.next())
			{

				
				retrait = new Retraits(
						rs.getInt("no_article"),
						rs.getString("rue"),
						rs.getString("code_postal"),
						rs.getString("ville")
						);
						
			}else {
				System.out.println("select by noArticle : retrait null");
				//FIXME gerer exception
			}
			
		
		} catch (Exception e) {
			throw new DALException("Erreur de selectByNoArticle",e);
		}
		return retrait;
	}
	

	
	//TO DO
	@Override
	public List<Retraits> selectAll() throws DALException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Retraits retraits) throws DALException {
		PreparedStatement stmt = null;
		//Encheres ench= null;
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			stmt = cnx.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS);

			//FIXME gerer insertion dates
			//Date dateEnchere = null;

			//ajouter set.Time (prend sql.Time)
			stmt.setInt(1, retraits.getNoArticle());
			stmt.setString(2, retraits.getRue());
			stmt.setString(3, retraits.getCode_postal());
			stmt.setString(4, retraits.getVille());
	
			stmt.executeUpdate();						
			
		} catch (Exception e) {
			throw new DALException("Erreur d'insert",e);
		}
		
	}

	@Override
	public void update(Retraits retraits) throws DALException {
		// TODO Auto-generated method stub
		
	}

	
	//TO DO
	@Override
	public void delete(int noArticle) throws DALException {
		// TODO Auto-generated method stub
		
	}

}
