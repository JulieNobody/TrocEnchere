package fr.eni.trocenchere.dal;

import java.util.List;

import fr.eni.trocenchere.bo.Retraits;

public interface RetraitsDAO {

	
	public Retraits selectByNoArticle(int noArticle) throws DALException;
	public List<Retraits> selectAll() throws DALException;
	public void insert(Retraits retraits) throws DALException;
	public void update(Retraits retraits) throws DALException;
	public void delete(int noArticle) throws DALException;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
