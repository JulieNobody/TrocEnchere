package fr.eni.trocenchere.dal;

import java.util.List; 

import fr.eni.trocenchere.bo.Articles;

public interface ArticlesDAO {
	
	public Articles selectByNo(int noArticle) throws DALException;
	public List<Articles> selectByNoVendeur(int noVendeur) throws DALException;
	
	public List<Articles> selectAll() throws DALException;
	
	public List<Articles> selectEcTriNoArticle() throws DALException;
	public List<Articles> selectEcEtCategorie(int noCategorie) throws DALException;
	public List<Articles> selectEcEtMot(String motCle) throws DALException;
	public List<Articles> selectEcEtMotEtCategorie(String motCle, int categorie) throws DALException;
	
	public void insert(Articles article) throws DALException;
	public void update(Articles article) throws DALException;
	public void delete(int id) throws DALException;

}
