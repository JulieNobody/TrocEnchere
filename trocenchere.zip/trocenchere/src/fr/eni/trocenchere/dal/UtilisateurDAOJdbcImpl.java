package fr.eni.trocenchere.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import fr.eni.trocenchere.bo.Utilisateurs;

public class UtilisateurDAOJdbcImpl implements UtilisateurDAO {


	public static final String SELECTALL = "SELECT * FROM dbo.UTILISATEURS";
	public static final String SELECTBYPSEUDO = "SELECT * FROM dbo.UTILISATEURS WHERE pseudo=?";
	public static final String SELECTBYNOUTILISATEUR = "SELECT * FROM dbo.UTILISATEURS WHERE no_utilisateur=?";
	
	public static final String INSERT = "INSERT INTO dbo.UTILISATEURS(pseudo, nom, prenom, email, telephone, rue, code_postal, ville, mot_de_passe, credit, administrateur) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
	public static final String DELETE = "DELETE  FROM dbo.ARTICLES_VENDUS WHERE no_utilisateur=?;"
										+"DELETE  FROM dbo.UTILISATEURS WHERE no_utilisateur=?; ";
	public static final String UPDATE = "UPDATE dbo.UTILISATEURS set pseudo=?, nom=?, prenom=?, email=?, telephone=?, rue=?,code_postal=?,ville=?,mot_de_passe=?,credit=?,administrateur=? WHERE no_utilisateur=?";

	

	@Override
	public Utilisateurs selectByPseudo(String pseudo) throws DALException {
		Utilisateurs utilisateur = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			
			stmt = cnx.prepareStatement(SELECTBYPSEUDO);
			stmt.setString(1, pseudo);
		
			rs = stmt.executeQuery();

			
			if(rs.next())
			{
				Boolean admin = false;
				if (rs.getInt("administrateur") != 0)
				{
					admin = true;
				}
				
				utilisateur = new Utilisateurs(
						rs.getInt("no_utilisateur"),
					    pseudo,
					    rs.getString("nom"),
					    rs.getString("prenom"),
					   	rs.getString("email"),
					    rs.getString("telephone"),
					    rs.getString("rue"),
					    rs.getString("code_postal"),
					    rs.getString("ville"),
					   	rs.getString("mot_de_passe"),
					   	rs.getInt("credit"),
					   	admin
						);
			}else {
				System.out.println("select by pseudo : utilisateur null");
				//FIXME gerer exception
			}
			
		
		} catch (Exception e) {
			throw new DALException("Erreur de selectByPseudo",e);
		}
		return utilisateur;
	}
	
	
	
	public Utilisateurs selectByNoUtilisateur(int noUtilisateur) throws DALException
	{
		Utilisateurs utilisateur = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			
			stmt = cnx.prepareStatement(SELECTBYNOUTILISATEUR);
			stmt.setInt(1, noUtilisateur);
		
			rs = stmt.executeQuery();

			
			if(rs.next())
			{
				Boolean admin = false;
				if (rs.getInt("administrateur") != 0)
				{
					admin = true;
				}
				
				utilisateur = new Utilisateurs(
						rs.getInt("no_utilisateur"),
					    rs.getString("pseudo"),
					    rs.getString("nom"),
					    rs.getString("prenom"),
					   	rs.getString("email"),
					    rs.getString("telephone"),
					    rs.getString("rue"),
					    rs.getString("code_postal"),
					    rs.getString("ville"),
					   	rs.getString("mot_de_passe"),
					   	rs.getInt("credit"),
					   	admin
						);
			}else {
				System.out.println("select by noUtilisateur : utilisateur null");
				//FIXME gerer exception
			}
			
		
		} catch (Exception e) {
			throw new DALException("Erreur de selectByNoUtilisateur",e);
		}
		return utilisateur;
	
	}



	@Override
	public List<Utilisateurs> selectAll() throws DALException {
		List<Utilisateurs> listeUtilisateurs = new ArrayList<Utilisateurs>();
		
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			
			Statement stmt = cnx.createStatement();
			ResultSet rs = stmt.executeQuery(SELECTALL);
					
			
			while(rs.next()) {
				Utilisateurs utilisateurs = new Utilisateurs (rs.getInt("no_utilisateur"), rs.getString("pseudo"), rs.getString("nom"), rs.getString("prenom"), 
						rs.getString("email"),rs.getString("telephone"), rs.getString("rue"), rs.getString("code_postal"), rs.getString("ville"),
						rs.getString("mot_de_passe"), rs.getInt("credit") , rs.getBoolean("administrateur"));
				
				listeUtilisateurs.add(utilisateurs);
			}
			
		} catch (Exception e) {
			throw new DALException("Erreur de selectAll",e);
		}
		
		return listeUtilisateurs;
	}


	@Override
	public void insert(Utilisateurs utilisateurs) throws DALException {
		PreparedStatement stmt = null;
		
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			stmt = cnx.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS);

			stmt.setString(1, utilisateurs.getPseudo());
			stmt.setString(2, utilisateurs.getNom());
			stmt.setString(3, utilisateurs.getPrenom());
			stmt.setString(4, utilisateurs.getEmail());
			stmt.setString(5, utilisateurs.getTelephone());
			stmt.setString(6, utilisateurs.getRue());
			stmt.setString(7, utilisateurs.getCode_postal());
			stmt.setString(8, utilisateurs.getVille());
			stmt.setString(9, utilisateurs.getMot_de_passe());
			stmt.setInt(10, utilisateurs.getCredit());
			stmt.setBoolean(11, utilisateurs.isAdministrateur());
			
			stmt.executeUpdate();
			
			
			
			ResultSet rsNoUtilisateur = stmt.getGeneratedKeys();
			if(rsNoUtilisateur.next()) {
				utilisateurs.setNo_utilisateur(rsNoUtilisateur.getInt(1));
			}
			
		} catch (Exception e) {
			throw new DALException("Erreur d'insert",e);
		}
	}


	@Override
	public void update(Utilisateurs utilisateurs) throws DALException {
		
		PreparedStatement stmt = null;
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			stmt = cnx.prepareStatement(UPDATE);
			stmt.setString(1, utilisateurs.getPseudo());
			stmt.setString(2, utilisateurs.getNom());
			stmt.setString(3, utilisateurs.getPrenom());
			stmt.setString(4, utilisateurs.getEmail());
			stmt.setString(5, utilisateurs.getTelephone());
			stmt.setString(6, utilisateurs.getRue());
			stmt.setString(7, utilisateurs.getCode_postal());
			stmt.setString(8, utilisateurs.getVille());
			stmt.setString(9, utilisateurs.getMot_de_passe());
			stmt.setInt(10, utilisateurs.getCredit());
			stmt.setBoolean(11, utilisateurs.isAdministrateur());
			stmt.setInt(12, utilisateurs.getNo_utilisateur());
			
			stmt.executeUpdate();
			
			
			
		} catch (Exception e) {
			throw new DALException("Erreur de modification",e);
		}
		
	}


	@Override
	public boolean delete(int NoUtilisateur) throws DALException {
		
		PreparedStatement stmt = null;
		boolean isOk = false;
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			System.out.println("delete en cours de l'utilisateur n° "+NoUtilisateur);
			stmt = cnx.prepareStatement(DELETE);
			System.out.println("state prepare");
			stmt.setInt(1, NoUtilisateur);
			stmt.setInt(2, NoUtilisateur);
			System.out.println("delete pret a exec");
			stmt.executeUpdate();
			System.out.println("delete exec");
			isOk = true; 
			
		} catch (Exception e) {
			System.out.println("delete a souleve une exception");
			throw new DALException("Erreur de suppression",e);

		}
		
		return isOk;
	}

	
	
	
}
