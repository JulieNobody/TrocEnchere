package fr.eni.trocenchere.dal;


public class DAOFactory
{

	public static UtilisateurDAO getUtilisateurDAO() 
	{
		return new UtilisateurDAOJdbcImpl();
	}
	
	public static ArticlesDAO getArticleDAO() 
	{
		return new ArticlesDAOJdbcImpl();
	}
	
	public static RetraitsDAO getRetraitsDAO()
	{
		return new RetraitsDAOJdbcImpl();
	}
}
