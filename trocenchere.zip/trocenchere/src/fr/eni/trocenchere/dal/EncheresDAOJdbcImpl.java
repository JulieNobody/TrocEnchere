package fr.eni.trocenchere.dal;

import fr.eni.trocenchere.bo.Encheres;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

import fr.eni.trocenchere.bo.Articles;
import fr.eni.trocenchere.bo.Utilisateurs;

public class EncheresDAOJdbcImpl implements EncheresDAO{
	
	//---------------------- REQUETES ----------------------
	
	public static final String SELECTBYUTILISATEUR = 
		"SELECT  FROM dbo.ENCHERES WHERE no_utilisateur=?";
	public static final String SELECTBYARTICLE = 
			"SELECT * FROM dbo.ENCHERES WHERE no_article=? ORDER BY montant_enchere";
	public static final String SELECTALL = 
			"SELECT * FROM dbo.ENCHERES";
	public static final String INSERT = 
			"INSERT INTO dbo.ENCHERES "
			+ "( no_utilisateur, no_article, date_enchere, montant_enchere) "
			+ "VALUES(?,?,?,?)";
	//UPDATE : pas d'update du No d'utilisateur
	public static final String UPDATE = 
			"UPDATE dbo.ENCHERES set "
			+ "no_utilisateur=?, no_article=?, date_enchere=?, montant_enchere=?"
			+ "WHERE no_article=?";
	public static final String DELETE = 
			"DELETE FROM dbo.ENCHERES WHERE no_utilisateur=? AND no_article=?";


	//---------------------- SELECT ----------------------
	@Override
	public Encheres selectByNoUtilisateur(int noUtilisateur) throws DALException {
		Encheres enchere = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try(Connection cnx = ConnectionProvider.getConnection())
		{
			
			stmt = cnx.prepareStatement(SELECTBYUTILISATEUR);
			stmt.setInt(1, noUtilisateur);
		
			rs = stmt.executeQuery();

			

			if(rs.next())
			{

				LocalDateTime dateEnchere = LocalDateTime.of(rs.getDate("date_enchere").toLocalDate(),rs.getTime("date_enchere").toLocalTime());								
				
				enchere = new Encheres(
						rs.getInt("no_utilisateur"),
						rs.getInt("no_article"),
						dateEnchere,
						rs.getInt("montant_enchere")
						);
						
			}else {
				System.out.println("select by pseudo : utilisateur null");
				//FIXME gerer exception
			}
			
		
		} catch (Exception e) {
			throw new DALException("Erreur de selectByPseudo",e);
		}
		return enchere;
	}

	
	
	
	public List<Encheres> selectByNoArticle(int noArticle) throws DALException {
		Encheres enchere = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Encheres> listeEncheres = new ArrayList<Encheres>();
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			
			stmt = cnx.prepareStatement(SELECTBYARTICLE);
			stmt.setInt(1, noArticle);
		
			rs = stmt.executeQuery();

			

			while(rs.next())
			{

				LocalDateTime dateEnchere = LocalDateTime.of(rs.getDate("date_enchere").toLocalDate(),rs.getTime("date_enchere").toLocalTime());								
				
				enchere = new Encheres(
						rs.getInt("no_utilisateur"),
						rs.getInt("no_article"),
						dateEnchere,
						rs.getInt("montant_enchere")
						);
				
				listeEncheres.add(enchere);
						
			}
			
		
		} catch (Exception e) {
			throw new DALException("Erreur de selectByPseudo",e);
		}
		return listeEncheres;
	}
	
	
	
	
	@Override
	public List<Encheres> selectAll() throws DALException {
		
		List<Encheres> listeEncheres = new ArrayList<Encheres>();
		
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			Statement stmt = cnx.createStatement();
			ResultSet rs = stmt.executeQuery(SELECTALL);
					
			while(rs.next()) {
				
				
				//FIXME gerer insertion dates
				LocalDateTime dateEnchere = LocalDateTime.of(rs.getDate("date_enchere").toLocalDate(),rs.getTime("date_enchere").toLocalTime());
				Encheres enchere = new Encheres();
				enchere= new Encheres(
						rs.getInt("no_utilisateur"),
						rs.getInt("no_article"),
						dateEnchere,
						rs.getInt("montant_enchere")
						);
						
				
				listeEncheres.add(enchere);
			}
			
		} catch (Exception e) {
			throw new DALException("Erreur de selectAll",e);
		}
		return listeEncheres;
	}

	//---------------------- MODIF BDD ----------------------
	@Override
	public void insert(Encheres enchere) throws DALException {
		PreparedStatement stmt = null;
		//Encheres ench= null;
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			stmt = cnx.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS);

			//FIXME gerer insertion dates
			//Date dateEnchere = null;

			//ajouter set.Time (prend sql.Time)
			stmt.setInt(1, enchere.getNoAcheteur());
			stmt.setInt(2, enchere.getNoArticle());
			stmt.setTimestamp(3,Timestamp.valueOf(enchere.getDateEnchere()));
			stmt.setInt(4, enchere.getMontantEnchere());
	
			stmt.executeUpdate();						
			
		} catch (Exception e) {
			throw new DALException("Erreur d'insert",e);
		}
		
	}
	
	
	@Override
	public void delete(int noAcheteur, int noArticle) throws DALException {

		PreparedStatement stmt = null;
		
		
	
	try(Connection cnx = ConnectionProvider.getConnection())
		{
			
			stmt = cnx.prepareStatement(DELETE);
			stmt.setInt(1, noAcheteur);
			stmt.setInt(2,noArticle);
			stmt.executeUpdate();
			
			
	} catch (Exception e) {
		throw new DALException("Erreur de suppression",e);
		}
			
	}
	
	
/*
	@Override
	public void update(Encheres enchere) throws DALException {
		PreparedStatement stmt = null;
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			
			stmt = cnx.prepareStatement(UPDATE);
			
			//FIXME gerer insertion dates
			Date dateDebutEnchere = null;
			Date dateFinEnchere = null;	
			//ajouter set.Time (prend sql.Time)
			
			stmt.setString(1, article.getNomArticle());
			stmt.setString(2, article.getDescription());
			stmt.setDate(3, dateDebutEnchere);
			stmt.setDate(4, dateFinEnchere);
			stmt.setInt(5, article.getPrixInitial());
			stmt.setInt(6, article.getPrixVente());
			stmt.setInt(7, article.getNoCategorie());
			stmt.setString(8, article.getEtatVente());
			stmt.setString(9, article.getImage());
			
			stmt.executeUpdate();			
			
		} catch (Exception e) {
			throw new DALException("Erreur de modification",e);
		}
		
	}*/



	
	
	
	
	
	
	
	
}
