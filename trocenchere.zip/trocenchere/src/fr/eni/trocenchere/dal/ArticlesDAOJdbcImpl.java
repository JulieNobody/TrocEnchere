﻿package fr.eni.trocenchere.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

import fr.eni.trocenchere.bo.Articles;
import fr.eni.trocenchere.bo.Utilisateurs;

/** Gestion des articles de la BDD */
public class ArticlesDAOJdbcImpl implements ArticlesDAO{
	
	//---------------------- REQUETES ----------------------
	
	public static final String SELECTBYNUMERO = 
		"SELECT * FROM dbo.ARTICLES_VENDUS WHERE no_article=?";
	
	public static final String SELECT_BY_NO_VENDEUR = 
			"SELECT * FROM dbo.ARTICLES_VENDUS WHERE no_utilisateur=?";
	
	public static final String SELECTALL = 
			"SELECT * FROM dbo.ARTICLES_VENDUS";
	
	public static final String INSERT = 
			"INSERT INTO dbo.ARTICLES_VENDUS "
			+ "(nom_article, description, date_debut_enchere, date_fin_enchere, prix_initial, prix_vente, no_utilisateur, no_categorie, etat_vente, image) "
			+ "VALUES(?,?,?,?,?,?,?,?,?,?)";
	
	//requête UPDATE : pas d'update du No d'utilisateur
	public static final String UPDATE = 
			"UPDATE dbo.ARTICLES_VENDUS set "
			+ "nom_article=?, description=?, date_debut_enchere=?, date_fin_enchere=?, prix_initial=?, prix_vente=?, no_categorie=?, etat_vente=?,image=? "
			+ "WHERE no_article=?";
	
	public static final String DELETE = 
			"DELETE FROM dbo.ARTICLES_VENDUS WHERE no_article=?; "
			+ "DELETE FROM dbo.ENCHERES WHERE no_article=?; "
			+ "DELETE FROM dbo.RETRAITS WHERE no_article=?; ";
	
	public static final String SELECT_EC_TRI_NOARTICLE = "SELECT * FROM dbo.ARTICLES_VENDUS "
			+ "WHERE etat_vente = 'EC' "
			+ "ORDER BY no_article DESC;";
	
	public static final String SELECT_EC_CATEGORIE = "SELECT * FROM ARTICLES_VENDUS " + 
			" WHERE etat_vente = 'EC' AND no_categorie = ? " + 
			"ORDER BY no_article DESC;";
	
	public static final String SELECT_EC_MOT = "SELECT * FROM ARTICLES_VENDUS " + 
			"WHERE etat_vente = 'EC' AND nom_article LIKE ? " +
			"ORDER BY no_article DESC;";
	
	public static final String SELECT_EC_MOT_CATEGORIE = "SELECT * FROM ARTICLES_VENDUS "
			+ "WHERE etat_vente = 'EC' AND nom_article	LIKE ? AND no_categorie = ? "
			+ "ORDER BY no_article DESC; ";
		
	//---------------------- SELECT ----------------------
	
	/** extraction de la BDD : 1 article par son no d'article
	 * @param noArticle : numéro de l'article
	 * @return article demandé
	 */
	@Override
	public Articles selectByNo(int noArticle) throws DALException
	{
		Articles article = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		//utilisation du pool de connexion
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			//préparation de la requête SQL
			stmt = cnx.prepareStatement(SELECTBYNUMERO);
			stmt.setInt(1, noArticle);
		
			//exécution de la requête et récupération du résultat de la requête
			rs = stmt.executeQuery();
			
			//consultation du résultat  de la requête
			if(rs.next())
			{
				//transformation des date/heure du format SQL à Java
				LocalDateTime dateDebutEnchere = LocalDateTime.of(rs.getDate("date_debut_enchere").toLocalDate(),rs.getTime("date_debut_enchere").toLocalTime());
				LocalDateTime dateFinEnchere = LocalDateTime.of(rs.getDate("date_fin_enchere").toLocalDate(),rs.getTime("date_fin_enchere").toLocalTime());
				
				//construction d'un Article avec les données de la BDD
				article = new Articles(
						noArticle,
						rs.getString("nom_article"),
						rs.getString("description"),
						dateDebutEnchere,
						dateFinEnchere,
						rs.getInt("prix_initial"),
						rs.getInt("prix_vente"),
						rs.getInt("no_utilisateur"),
						rs.getInt("no_categorie"),
						rs.getString("etat_vente"),
						rs.getString("image")
						);
			}else {
				System.out.println("select by pseudo : article null");
			}
		} catch (Exception e) {
			throw new DALException("Erreur de selectByPseudo",e);
		}
		return article;
	}

	/** extraction de la BDD : liste d'articles par le numéro du vendeur
	 * @param noVendeur : numéro du vendeur
	 * @return liste d'articles demandée
	 */
	@Override
	public List<Articles> selectByNoVendeur(int noVendeur) throws DALException
	{
		List<Articles> listeArticles = new ArrayList<Articles>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		//utilisation du pool de connexion
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			//préparation de la requête SQL
			stmt = cnx.prepareStatement(SELECT_BY_NO_VENDEUR);
			stmt.setInt(1, noVendeur);
			
			//exécution de la requête et récupération du résultat de la requête
			rs = stmt.executeQuery();
			
			//consultation du résultat  de la requête
			while(rs.next())
			{
				//transformation des date/heure du format SQL à Java				
				LocalDateTime dateDebutEnchere = LocalDateTime.of(rs.getDate("date_debut_enchere").toLocalDate(),rs.getTime("date_debut_enchere").toLocalTime());
				LocalDateTime dateFinEnchere = LocalDateTime.of(rs.getDate("date_fin_enchere").toLocalDate(),rs.getTime("date_fin_enchere").toLocalTime());
				
				//construction d'un Article avec les données de la BDD
				Articles article = new Articles(
						rs.getInt("no_article"),
						rs.getString("nom_article"),
						rs.getString("description"),
						dateDebutEnchere,
						dateFinEnchere,
						rs.getInt("prix_initial"),
						rs.getInt("prix_vente"),
						rs.getInt("no_utilisateur"),
						rs.getInt("no_categorie"),
						rs.getString("etat_vente"),
						rs.getString("image")
						);
				//ajout de l'article créé à la liste
				listeArticles.add(article);
			}
		} catch (Exception e) {
			throw new DALException("Erreur de selectByNoVendeur",e);
		}
		return listeArticles;
	}
	
	/** extraction de la BDD : liste de tous les articles
	 * @return liste d'articles demandée
	 */
	@Override
	public List<Articles> selectAll() throws DALException
	{
		List<Articles> listeArticles = new ArrayList<Articles>();
		
		//utilisation du pool de connexion
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			///préparation de la requête SQL
			Statement stmt = cnx.createStatement();
			
			//exécution de la requête et récupération du résultat de la requête
			ResultSet rs = stmt.executeQuery(SELECTALL);
			
			//consultation du résultat  de la requête
			while(rs.next())
			{
				//transformation des date/heure du format SQL à Java				
				LocalDateTime dateDebutEnchere = LocalDateTime.of(rs.getDate("date_debut_enchere").toLocalDate(),rs.getTime("date_debut_enchere").toLocalTime());
				LocalDateTime dateFinEnchere = LocalDateTime.of(rs.getDate("date_fin_enchere").toLocalDate(),rs.getTime("date_fin_enchere").toLocalTime());
				
				//construction d'un Article avec les données de la BDD
				Articles article = new Articles(
						rs.getInt("no_article"),
						rs.getString("nom_article"),
						rs.getString("description"),
						dateDebutEnchere,
						dateFinEnchere,
						rs.getInt("prix_initial"),
						rs.getInt("prix_vente"),
						rs.getInt("no_utilisateur"),
						rs.getInt("no_categorie"),
						rs.getString("etat_vente"),
						rs.getString("image")
						);
				
				//ajout de l'article créé à la liste
				listeArticles.add(article);
			}
		} catch (Exception e) {
			throw new DALException("Erreur de selectAll",e);
		}
		return listeArticles;
	}

	
	/** extraction de la BDD : liste d'articles en vente (EC), du plus récent au plus ancien
	 * @return liste d'articles demandée
	 */
	@Override
	public List<Articles> selectEcTriNoArticle() throws DALException
	{	
		List<Articles> listeArticles = new ArrayList<Articles>();
		
		//utilisation du pool de connexion
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			//préparation de la requête SQL
			Statement stmt = cnx.createStatement();
			
			//exécution de la requête et récupération du résultat de la requête
			ResultSet rs = stmt.executeQuery(SELECT_EC_TRI_NOARTICLE);
			
			//consultation du résultat  de la requête
			while(rs.next()) {
				//transformation des date/heure du format SQL à Java				
				LocalDateTime dateDebutEnchere = LocalDateTime.of(rs.getDate("date_debut_enchere").toLocalDate(),rs.getTime("date_debut_enchere").toLocalTime());
				LocalDateTime dateFinEnchere = LocalDateTime.of(rs.getDate("date_fin_enchere").toLocalDate(),rs.getTime("date_fin_enchere").toLocalTime());
				
				//construction d'un Article avec les données de la BDD
				Articles article = new Articles(
						rs.getInt("no_article"),
						rs.getString("nom_article"),
						rs.getString("description"),
						dateDebutEnchere,
						dateFinEnchere,
						rs.getInt("prix_initial"),
						rs.getInt("prix_vente"),
						rs.getInt("no_utilisateur"),
						rs.getInt("no_categorie"),
						rs.getString("etat_vente"),
						rs.getString("image")
						);
				//ajout de l'article créé à la liste
				listeArticles.add(article);
			}
		} catch (Exception e) {
			throw new DALException("Erreur de selectEcTriNoArticle",e);
		}
		return listeArticles;
	}
	
	
	/** extraction de la BDD : liste d'articles en vente (EC), 
	 * de la catégorie demandée, du plus récent au plus ancien
	 * @param noCategorie : numéro de la catégorie selectionée
	 * @return liste d'articles demandée
	 */
	@Override
	public List<Articles> selectEcEtCategorie(int noCategorie) throws DALException
	{	
		List<Articles> listeArticles = new ArrayList<Articles>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		//utilisation du pool de connexion
		try(Connection cnx = ConnectionProvider.getConnection())
		{
					
			//préparation de la requête SQL			
			stmt = cnx.prepareStatement(SELECT_EC_CATEGORIE);
			stmt.setInt(1, noCategorie);
			
			//exécution de la requête et récupération du résultat de la requête
			rs = stmt.executeQuery();
			
			//consultation du résultat  de la requête
			while(rs.next()) {
				
				//transformation des date/heure du format SQL à Java				
				LocalDateTime dateDebutEnchere = LocalDateTime.of(rs.getDate("date_debut_enchere").toLocalDate(),rs.getTime("date_debut_enchere").toLocalTime());
				LocalDateTime dateFinEnchere = LocalDateTime.of(rs.getDate("date_fin_enchere").toLocalDate(),rs.getTime("date_fin_enchere").toLocalTime());
				
				//construction d'un Article avec les données de la BDD
				Articles article = new Articles(
						rs.getInt("no_article"),
						rs.getString("nom_article"),
						rs.getString("description"),
						dateDebutEnchere,
						dateFinEnchere,
						rs.getInt("prix_initial"),
						rs.getInt("prix_vente"),
						rs.getInt("no_utilisateur"),
						rs.getInt("no_categorie"),
						rs.getString("etat_vente"),
						rs.getString("image")
						);
				
				//ajout de l'article créé à la liste
				listeArticles.add(article);
			}
		} catch (Exception e) {
			throw new DALException("Erreur de selectEcEtCategorie",e);
		}
		return listeArticles;
	}
	
	/** extraction de la BDD : liste d'articles en vente (EC), 
	 * contenant un mot clé, du plus récent au plus ancien
	 * @param motCle : mot clé recherché dans le nom d'un article
	 * @return liste d'articles demandée
	 */
	@Override
	public List<Articles> selectEcEtMot(String motCle) throws DALException
	{
		List<Articles> listeArticles = new ArrayList<Articles>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		//utilisation du pool de connexion
		try(Connection cnx = ConnectionProvider.getConnection())
		{		
			//préparation de la requête SQL
			stmt = cnx.prepareStatement(SELECT_EC_MOT);
			stmt.setString(1, "%"+motCle+"%");

			//exécution de la requête et récupération du résultat de la requête
			rs = stmt.executeQuery();
			
			//consultation du résultat  de la requête
			while(rs.next()) {
				//transformation des date/heure du format SQL à Java				
				LocalDateTime dateDebutEnchere = LocalDateTime.of(rs.getDate("date_debut_enchere").toLocalDate(),rs.getTime("date_debut_enchere").toLocalTime());
				LocalDateTime dateFinEnchere = LocalDateTime.of(rs.getDate("date_fin_enchere").toLocalDate(),rs.getTime("date_fin_enchere").toLocalTime());
				
				//construction d'un Article avec les données de la BDD
				Articles article = new Articles(
						rs.getInt("no_article"),
						rs.getString("nom_article"),
						rs.getString("description"),
						dateDebutEnchere,
						dateFinEnchere,
						rs.getInt("prix_initial"),
						rs.getInt("prix_vente"),
						rs.getInt("no_utilisateur"),
						rs.getInt("no_categorie"),
						rs.getString("etat_vente"),
						rs.getString("image")
						);
				//ajout de l'article créé à la liste
				listeArticles.add(article);
			}
		} catch (Exception e) {
			throw new DALException("Erreur de selectEcEtMot",e);
		}
		return listeArticles;
	}

	/** extraction de la BDD : liste d'articles en vente (EC), 
	 * contenant un mot clé, une catégorie, et du plus récent au plus ancien
	 * @param motCle : mot clé recherché dans le nom d'un article
	 * @param noCategorie : numéro de la catégorie selectionée
	 * @return liste d'articles demandée
	 */
	@Override
	public List<Articles> selectEcEtMotEtCategorie(String motCle, int categorie) throws DALException
	{
		List<Articles> listeArticles = new ArrayList<Articles>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		//utilisation du pool de connexion
		try(Connection cnx = ConnectionProvider.getConnection())
		{	
			//préparation de la requête SQL
			stmt = cnx.prepareStatement(SELECT_EC_MOT_CATEGORIE);
			stmt.setString(1, "%"+motCle+"%");
			stmt.setInt(2, categorie);

			//exécution de la requête et récupération du résultat de la requête
			rs = stmt.executeQuery();
			
			//consultation du résultat  de la requête
			while(rs.next()) {
				//transformation des date/heure du format SQL à Java				
				LocalDateTime dateDebutEnchere = LocalDateTime.of(rs.getDate("date_debut_enchere").toLocalDate(),rs.getTime("date_debut_enchere").toLocalTime());
				LocalDateTime dateFinEnchere = LocalDateTime.of(rs.getDate("date_fin_enchere").toLocalDate(),rs.getTime("date_fin_enchere").toLocalTime());
				
				//construction d'un Article avec les données de la BDD
				Articles article = new Articles(
						rs.getInt("no_article"),
						rs.getString("nom_article"),
						rs.getString("description"),
						dateDebutEnchere,
						dateFinEnchere,
						rs.getInt("prix_initial"),
						rs.getInt("prix_vente"),
						rs.getInt("no_utilisateur"),
						rs.getInt("no_categorie"),
						rs.getString("etat_vente"),
						rs.getString("image")
						);
				//ajout de l'article créé à la liste
				listeArticles.add(article);
			}
			
		} catch (Exception e) {
			throw new DALException("Erreur de selectEcEtMot",e);
		}
		return listeArticles;
	}

	
	
	//---------------------- MODIF BDD ----------------------
	
	/** modification de la BDD : insertion d'un article
	 * @param article : article à insérer
	 */
	@Override
	public void insert(Articles article) throws DALException
	{
		PreparedStatement stmt = null;
		
		//utilisation du pool de connexion
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			//préparation de la requête SQL
			stmt = cnx.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, article.getNomArticle());
			stmt.setString(2, article.getDescription());
			stmt.setTimestamp(3, Timestamp.valueOf(article.getDateDebutEnchere()));
			stmt.setTimestamp(4, Timestamp.valueOf(article.getDateFinEnchere()));
			stmt.setInt(5, article.getPrixInitial());
			stmt.setInt(6, article.getPrixVente());
			stmt.setInt(7, article.getNoVendeur());
			stmt.setInt(8, article.getNoCategorie());
			stmt.setString(9, article.getEtatVente());
			stmt.setString(10, article.getImage());
			
			//exécution de la requête
			stmt.executeUpdate();						
			
			//mise à jour de l'article en paramètre avec le No généré par la BDD
			ResultSet rsNoArticle = stmt.getGeneratedKeys();
			if(rsNoArticle.next()) {
				article.setNoArticle(rsNoArticle.getInt(1));
			}
		} catch (Exception e) {
			throw new DALException("Erreur d'insert",e);
		}
	}

	/** modification de la BDD : modification d'un article
	 * @param article : article à modifier
	 */
	@Override
	public void update(Articles article) throws DALException
	{	
		PreparedStatement stmt = null;
		
		//utilisation du pool de connexion
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			//préparation de la requête SQL
			stmt = cnx.prepareStatement(UPDATE);
			stmt.setString(1, article.getNomArticle());
			stmt.setString(2, article.getDescription());
			stmt.setTimestamp(3, Timestamp.valueOf(article.getDateDebutEnchere()));
			stmt.setTimestamp(4, Timestamp.valueOf(article.getDateFinEnchere()));
			stmt.setInt(5, article.getPrixInitial());	
			stmt.setInt(6, article.getPrixVente());
			stmt.setInt(7, article.getNoCategorie());
			stmt.setString(8, article.getEtatVente());
			stmt.setString(9, article.getImage());
			stmt.setInt(10,article.getNoArticle());
			
			//exécution de la requête
			stmt.executeUpdate();			
		} catch (Exception e) {
			e.printStackTrace();
			throw new DALException("Erreur de modification",e);
		}
	}

	/** modification de la BDD : suppression d'un article
	 * reservé aux utilisateurs admin
	 * @param article : article à supprimer
	 */
	@Override
	public void delete(int id) throws DALException
	{
		PreparedStatement stmt = null;
		
		//utilisation du pool de connexion
		try(Connection cnx = ConnectionProvider.getConnection())
		{
			//préparation de la requête SQL
			stmt = cnx.prepareStatement(DELETE);
			stmt.setInt(1, id);
			stmt.setInt(2, id);
			stmt.setInt(3, id);
			
			//exécution de la requête
			stmt.executeQuery();
			
		} catch (Exception e) {
			throw new DALException("Erreur de suppression",e);
		}
	}	
}
