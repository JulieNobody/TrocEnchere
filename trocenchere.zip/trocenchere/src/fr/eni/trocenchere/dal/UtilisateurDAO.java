package fr.eni.trocenchere.dal;

import java.sql.ResultSet;
import java.util.List;


import fr.eni.trocenchere.bo.Utilisateurs;

public interface UtilisateurDAO {

		
		public Utilisateurs selectByPseudo(String pseudo) throws DALException;
		public Utilisateurs selectByNoUtilisateur(int noUtilisateur) throws DALException;
		public List<Utilisateurs> selectAll() throws DALException;
		public void insert(Utilisateurs utilisateurs) throws DALException;
		public void update(Utilisateurs utilisateurs) throws DALException;
		public boolean delete(int id) throws DALException;
		
		
}
