package fr.eni.trocenchere.dal;
import fr.eni.trocenchere.bo.Encheres;
import java.util.List; 

import fr.eni.trocenchere.bo.Articles;

public interface EncheresDAO {
	
	
	public Encheres selectByNoUtilisateur(int noUtilisateur) throws DALException;
	public List<Encheres> selectByNoArticle(int noArticle) throws DALException;
	public List<Encheres> selectAll() throws DALException;
	public void insert(Encheres enchere) throws DALException;
	//public void update(Encheres enchere) throws DALException;
	public void delete(int noAcheteur, int noArticle) throws DALException;
	
	

}
